Teacher Support and Assessment
==============================

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Teacher Primer, Disclosure and Incident Guide, Counselor Heads-Up and Opt-Out Toolkit, Inclusion and Equity Guide, FAQ, Assessment Pack, Hackles Day Kit.

  Assessment_Pack.docx
  Assessment_Pack.pdf
  Counselor_Heads_Up_and_Opt_Out_Toolkit.docx
  Counselor_Heads_Up_and_Opt_Out_Toolkit.pdf
  Disclosure_and_Incident_Guide.docx
  Disclosure_and_Incident_Guide.pdf
  Hackles_Day_Kit.docx
  Hackles_Day_Kit.pdf
  Inclusion_and_Equity_Guide.docx
  Inclusion_and_Equity_Guide.pdf
  Teacher_FAQ_25_Questions.docx
  Teacher_FAQ_25_Questions.pdf
  Teacher_Primer.docx
  Teacher_Primer.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
