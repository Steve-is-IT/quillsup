Administrator and IT Pack
=========================

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Procurement brief, privacy and accessibility statements, policy and board documents, crisis flowchart, IT checklist, checksums and the implementation tracker.

  29_Admin/00_Start_Here_Administrators.docx
  29_Admin/00_Start_Here_Administrators.pdf
  29_Admin/01_Free_Resource_Procurement_Brief.docx
  29_Admin/01_Free_Resource_Procurement_Brief.pdf
  29_Admin/02_Security_and_Privacy_Questionnaire.docx
  29_Admin/02_Security_and_Privacy_Questionnaire.pdf
  29_Admin/03_Data_Flow_Statement.docx
  29_Admin/03_Data_Flow_Statement.pdf
  29_Admin/04_Accessibility_Conformance_Statement.docx
  29_Admin/04_Accessibility_Conformance_Statement.pdf
  29_Admin/05_License_and_Open_Source_Summary.docx
  29_Admin/05_License_and_Open_Source_Summary.pdf
  29_Admin/05b_License_Texts_Appendix.docx
  29_Admin/05b_License_Texts_Appendix.pdf
  29_Admin/06_Board_Memo_and_Consent_Agenda.docx
  29_Admin/06_Board_Memo_and_Consent_Agenda.pdf
  29_Admin/07_Model_Policy_Internet_Safety_Instruction.docx
  29_Admin/07_Model_Policy_Internet_Safety_Instruction.pdf
  29_Admin/08_Parent_Letter_Set.docx
  29_Admin/08_Parent_Letter_Set.pdf
  29_Admin/09_Staff_Memo.docx
  29_Admin/09_Staff_Memo.pdf
  29_Admin/10_Counselor_Coordination_Protocol.docx
  29_Admin/10_Counselor_Coordination_Protocol.pdf
  29_Admin/11_Crisis_Disclosure_Flowchart.pdf
  29_Admin/11_Crisis_Disclosure_Flowchart.svg
  29_Admin/11_Crisis_Disclosure_Flowchart_Text.docx
  29_Admin/11_Crisis_Disclosure_Flowchart_Text.pdf
  29_Admin/12_Scheduling_and_Pacing_Planner.docx
  29_Admin/12_Scheduling_and_Pacing_Planner.pdf
  29_Admin/13_Communications_Kit.docx
  29_Admin/13_Communications_Kit.pdf
  29_Admin/14_IT_and_Library_Checklist.docx
  29_Admin/14_IT_and_Library_Checklist.pdf
  29_Admin/15_Implementation_Tracker_Guide.docx
  29_Admin/15_Implementation_Tracker_Guide.pdf
  29_Admin/16_Implementation_in_30_Days.docx
  29_Admin/16_Implementation_in_30_Days.pdf
  29_Admin/17_Hackles_Day_in_a_Box.docx
  29_Admin/17_Hackles_Day_in_a_Box.pdf
  29_Admin/CHECKSUMS.txt
  29_Admin/CHECKSUMS_FOLDERS.txt
  29_Admin/Hackles_Day_Budget.xlsx
  29_Admin/Hackles_Implementation_Tracker.xlsx
  29_Admin/Hackles_Implementation_Tracker_EXAMPLE.xlsx
  29_Admin/licence_texts/CC-BY-NC-4.0_legalcode.txt
  29_Admin/licence_texts/Caveat-OFL.txt
  29_Admin/licence_texts/Fraunces-OFL.txt
  29_Admin/licence_texts/SourceSerif4-OFL.txt
  29_Admin/licence_texts/SpecialElite-Apache-2.0.txt

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
