Hackles Lab
===========

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Six interactive classroom tools that run offline in any browser. Open index.html. No accounts, no data.

  26_Lab/assets/art.js
  26_Lab/assets/art.json
  26_Lab/assets/art/buddy.png
  26_Lab/assets/art/crew_group.png
  26_Lab/assets/art/ember.png
  26_Lab/assets/art/fixit.png
  26_Lab/assets/art/hackle_curious.png
  26_Lab/assets/art/hackle_down.png
  26_Lab/assets/art/hackle_happy.png
  26_Lab/assets/art/hackle_helping.png
  26_Lab/assets/art/hackle_proud.png
  26_Lab/assets/art/hackle_silly.png
  26_Lab/assets/art/hackle_sleepy.png
  26_Lab/assets/art/hackle_up.png
  26_Lab/assets/art/latch.png
  26_Lab/assets/art/peeper.png
  26_Lab/assets/art/pip.png
  26_Lab/assets/css/lab.css
  26_Lab/assets/fonts/Caveat-OFL.txt
  26_Lab/assets/fonts/Caveat-VF.ttf
  26_Lab/assets/fonts/Fraunces-Italic-VF.ttf
  26_Lab/assets/fonts/Fraunces-OFL.txt
  26_Lab/assets/fonts/Fraunces-VF.ttf
  26_Lab/assets/fonts/SourceSerif4-Italic-VF.ttf
  26_Lab/assets/fonts/SourceSerif4-OFL.txt
  26_Lab/assets/fonts/SourceSerif4-VF.ttf
  26_Lab/assets/icons/icon_fix_it.svg
  26_Lab/assets/icons/icon_kind_and_well.svg
  26_Lab/assets/icons/icon_lock_it.svg
  26_Lab/assets/icons/icon_safe_people.svg
  26_Lab/assets/icons/icon_share_smart.svg
  26_Lab/assets/icons/icon_spot_it.svg
  26_Lab/assets/icons/orn_asterism.svg
  26_Lab/assets/icons/orn_registration.svg
  26_Lab/assets/icons/orn_rule_diamond.svg
  26_Lab/assets/icons/orn_rule_double.svg
  26_Lab/assets/icons/orn_stamp_frame_rect.svg
  26_Lab/assets/icons/orn_tuft.svg
  26_Lab/assets/js/core.js
  26_Lab/assets/js/home.js
  26_Lab/assets/js/util.js
  26_Lab/data-detective/app.js
  26_Lab/data-detective/data.js
  26_Lab/data-detective/detective-logic.js
  26_Lab/data-detective/index.html
  26_Lab/data-detective/strings.js
  26_Lab/hackles-or-not/app.js
  26_Lab/hackles-or-not/data.js
  26_Lab/hackles-or-not/index.html
  26_Lab/hackles-or-not/ornot-logic.js
  26_Lab/hackles-or-not/strings.js
  26_Lab/help-ladder-trail/app.js
  26_Lab/help-ladder-trail/data.js
  26_Lab/help-ladder-trail/index.html
  26_Lab/help-ladder-trail/strings.js
  26_Lab/help-ladder-trail/trail-logic.js
  26_Lab/index.html
  26_Lab/passphrase-lab/app.js
  26_Lab/passphrase-lab/index.html
  26_Lab/passphrase-lab/pass-logic.js
  26_Lab/passphrase-lab/strings.js
  26_Lab/secret-code-lab/app.js
  26_Lab/secret-code-lab/cipher-logic.js
  26_Lab/secret-code-lab/index.html
  26_Lab/secret-code-lab/strings.js
  26_Lab/spot-the-fishy/app.js
  26_Lab/spot-the-fishy/data.js
  26_Lab/spot-the-fishy/index.html
  26_Lab/spot-the-fishy/spot-logic.js
  26_Lab/spot-the-fishy/strings.js

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
