3-5: Hands-On Hackers (ages 8-10)
=================================

Hackles: a free kit. The whole kit is at quillsup.org

WHAT IS INSIDE
--------------
Teacher guide, student activity book, cards. Answer key in TEACHERS_ONLY.

  3-5_Reproducibles.docx
  3-5_Reproducibles.pdf
  3-5_Student_Activity_Book.docx
  3-5_Student_Activity_Book.pdf
  3-5_Teacher_Guide.docx
  3-5_Teacher_Guide.pdf
  TEACHERS_ONLY/3-5_Teacher_Answer_Key.docx
  TEACHERS_ONLY/3-5_Teacher_Answer_Key.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles (quillsup.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
