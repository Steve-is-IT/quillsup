State Alignment Atlas
=====================

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Online-safety instruction laws and standards for all 50 states and DC, with sources and unknowns. Not legal advice; re-verify citations before relying on them.

  Sources_A-M.docx
  Sources_A-M.pdf
  Sources_N-W.docx
  Sources_N-W.pdf
  States_A-M.docx
  States_A-M.pdf
  States_N-W.docx
  States_N-W.pdf
  Unknowns_A-M.docx
  Unknowns_A-M.pdf
  Unknowns_N-W.docx
  Unknowns_N-W.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
