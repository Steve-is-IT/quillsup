9-12: Your Digital Defense Plan (ages 14-18)
============================================

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Teacher guide, student workbook, cards. Answer key in TEACHERS_ONLY. Includes sensitive lessons: give your counselor a heads-up first.

  9-12_Reproducibles.docx
  9-12_Reproducibles.pdf
  9-12_Student_Workbook.docx
  9-12_Student_Workbook.pdf
  9-12_Teacher_Guide.docx
  9-12_Teacher_Guide.pdf
  TEACHERS_ONLY/9-12_Teacher_Answer_Key.docx
  TEACHERS_ONLY/9-12_Teacher_Answer_Key.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
