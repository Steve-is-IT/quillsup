Teacher Academy
===============

Hackles: a free kit. The whole kit is at quillsup.org

WHAT IS INSIDE
--------------
Self-paced training: 8 modules, assessments, certificate and badges, FAQ, glossary.

  Academy_Assessments.docx
  Academy_Assessments.pdf
  Academy_Certificate_and_Badges.docx
  Academy_Certificate_and_Badges.pdf
  Academy_FAQ.docx
  Academy_FAQ.pdf
  Academy_Glossary.docx
  Academy_Glossary.pdf
  Academy_Overview_and_Learning_Path.docx
  Academy_Overview_and_Learning_Path.pdf
  Module_1_Why_This_Matters.docx
  Module_1_Why_This_Matters.pdf
  Module_2_The_Cybersecurity_You_Need.docx
  Module_2_The_Cybersecurity_You_Need.pdf
  Module_3_How_Kids_Really_Live_Online.docx
  Module_3_How_Kids_Really_Live_Online.pdf
  Module_4_Teaching_Safety_That_Works.docx
  Module_4_Teaching_Safety_That_Works.pdf
  Module_5_Running_a_15_Minute_Hackles_Lesson.docx
  Module_5_Running_a_15_Minute_Hackles_Lesson.pdf
  Module_6_Sensitive_Topics_and_Disclosures.docx
  Module_6_Sensitive_Topics_and_Disclosures.pdf
  Module_7_Every_Learner_and_Every_Family.docx
  Module_7_Every_Learner_and_Every_Family.pdf
  Module_8_Measure_Reflect_Grow_and_Capstone.docx
  Module_8_Measure_Reflect_Grow_and_Capstone.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles (quillsup.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
