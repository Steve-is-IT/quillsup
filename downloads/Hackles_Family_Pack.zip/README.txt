Family Pack
===========

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Letters, conversation starters, family tech agreement, code word guide, glossary. Spanish drafts in Espanol/ when available.

  Espanol/01_K-2_Tarjetas_para_la_Familia.docx
  Espanol/01_K-2_Tarjetas_para_la_Familia.pdf
  Espanol/02_3-5_Tarjetas_para_la_Familia.docx
  Espanol/02_3-5_Tarjetas_para_la_Familia.pdf
  Espanol/06_Cartas_para_Familias_Temas_Sensibles.docx
  Espanol/06_Cartas_para_Familias_Temas_Sensibles.pdf
  Espanol/06_Familia_Paquete_para_Familias.docx
  Espanol/06_Familia_Paquete_para_Familias.pdf
  Family_Engagement_Pack.docx
  Family_Engagement_Pack.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
