Espanol (borrador / draft)
==========================

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Spanish drafts, NOT yet reviewed by a native speaker (borrador: pendiente de revision).

  00_Glosario_y_Guia_de_Traduccion.docx
  00_Glosario_y_Guia_de_Traduccion.pdf
  01_K-2_Libro_de_Actividades.docx
  01_K-2_Libro_de_Actividades.pdf
  01_K-2_Tarjetas_para_la_Familia.docx
  01_K-2_Tarjetas_para_la_Familia.pdf
  02_3-5_Libro_de_Actividades.docx
  02_3-5_Libro_de_Actividades.pdf
  02_3-5_Tarjetas_para_la_Familia.docx
  02_3-5_Tarjetas_para_la_Familia.pdf
  03_6-8_Cuaderno_del_Estudiante.docx
  03_6-8_Cuaderno_del_Estudiante.pdf
  03_6-8_Tarjetas_y_Materiales.docx
  03_6-8_Tarjetas_y_Materiales.pdf
  04_9-12_Cuaderno_del_Estudiante.docx
  04_9-12_Cuaderno_del_Estudiante.pdf
  04_9-12_Tarjetas_y_Materiales.docx
  04_9-12_Tarjetas_y_Materiales.pdf
  05_Docentes_Guia_Rapida.docx
  05_Docentes_Guia_Rapida.pdf
  06_Cartas_para_Familias_Temas_Sensibles.docx
  06_Cartas_para_Familias_Temas_Sensibles.pdf
  06_Familia_Paquete_para_Familias.docx
  06_Familia_Paquete_para_Familias.pdf
  07_Encuestas_Estudiantes.docx
  07_Encuestas_Estudiantes.pdf
  Glosario_Anexo_Tarjetas.docx
  Glosario_Anexo_Tarjetas.pdf
  TODO_new_lessons.docx
  TODO_new_lessons.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
