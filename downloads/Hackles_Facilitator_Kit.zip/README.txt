Facilitator Kit
===============

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Workshops, micro-PD, parent night script, coaching and train-the-trainer guides, principal checklist, plus the adult-only Volunteer Program.

  Facilitator_Evaluation_and_Certificates.docx
  Facilitator_Evaluation_and_Certificates.pdf
  Facilitator_Guide_Half_Day_Workshop.docx
  Facilitator_Guide_Half_Day_Workshop.pdf
  Handouts_and_Reproducibles.docx
  Handouts_and_Reproducibles.pdf
  Parent_Night_Presentation_Script.docx
  Parent_Night_Presentation_Script.pdf
  Peer_Coaching_and_Observation_Guide.docx
  Peer_Coaching_and_Observation_Guide.pdf
  Principal_Implementation_Checklist.docx
  Principal_Implementation_Checklist.pdf
  Staff_Meeting_Micro_PD_10_Sessions.docx
  Staff_Meeting_Micro_PD_10_Sessions.pdf
  Train_the_Trainer_Guide.docx
  Train_the_Trainer_Guide.pdf
  Volunteer_Program.docx
  Volunteer_Program.pdf
  Workshop_90_Minute_Version.docx
  Workshop_90_Minute_Version.pdf
  Workshop_Slide_Deck_Outline.docx
  Workshop_Slide_Deck_Outline.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
