Florida Pack
============

Hackles: a free kit. The whole kit is at quillsup.org

WHAT IS INSIDE
--------------
Florida HB 379 crosswalk (statute and the state's student guide), seven Plus lessons' gap analysis, district adoption guide and sources. NOT approved or endorsed by the Florida Department of Education.

  District_Adoption_Guide.docx
  District_Adoption_Guide.pdf
  Florida_HB379_Crosswalk.docx
  Florida_HB379_Crosswalk.pdf
  Florida_Statutes_and_Sources.docx
  Florida_Statutes_and_Sources.pdf
  Gap_Lesson_Stubs.docx
  Gap_Lesson_Stubs.pdf
  Plus_Lessons_Changelog.docx
  Plus_Lessons_Changelog.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles (quillsup.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
