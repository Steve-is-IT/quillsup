Slide decks
===========

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
47 lesson decks: offline HTML (open index.html) and editable PowerPoint files with speaker notes.

  25_Slides/html/assets/fonts/Caveat-VF.ttf
  25_Slides/html/assets/fonts/Fraunces-Italic-VF.ttf
  25_Slides/html/assets/fonts/Fraunces-VF.ttf
  25_Slides/html/assets/fonts/SourceSerif4-Italic-VF.ttf
  25_Slides/html/assets/fonts/SourceSerif4-VF.ttf
  25_Slides/html/assets/fonts/SpecialElite-Regular.ttf
  25_Slides/html/assets/fonts/licenses/Caveat-OFL.txt
  25_Slides/html/assets/fonts/licenses/Fraunces-OFL.txt
  25_Slides/html/assets/fonts/licenses/SourceSerif4-OFL.txt
  25_Slides/html/assets/fonts/licenses/SpecialElite-Apache-2.0.txt
  25_Slides/html/assets/img/hackle_curious.svg
  25_Slides/html/assets/img/hackle_happy.svg
  25_Slides/html/assets/img/hackle_helping.svg
  25_Slides/html/assets/img/hackle_proud.svg
  25_Slides/html/assets/img/hackle_silly.svg
  25_Slides/html/assets/img/hackle_up.svg
  25_Slides/html/assets/img/icon_fix_it.svg
  25_Slides/html/assets/img/icon_kind_and_well.svg
  25_Slides/html/assets/img/icon_lock_it.svg
  25_Slides/html/assets/img/icon_safe_people.svg
  25_Slides/html/assets/img/icon_share_smart.svg
  25_Slides/html/assets/img/icon_spot_it.svg
  25_Slides/html/g35-L01_the-help-ladder.html
  25_Slides/html/g35-L02_passphrase-lab.html
  25_Slides/html/g35-L03_scam-spotters.html
  25_Slides/html/g35-L04_secret-code-lab.html
  25_Slides/html/g35-L05_data-detective.html
  25_Slides/html/g35-L06_game-chat-red-flags.html
  25_Slides/html/g35-L07_upstander-moves.html
  25_Slides/html/g35-L08_real-or-fake.html
  25_Slides/html/g35-L09_family-code-word.html
  25_Slides/html/g35-L10_oops-recovery.html
  25_Slides/html/g68-L01_help-ladder-real-practice.html
  25_Slides/html/g68-L02_account-defense.html
  25_Slides/html/g68-L03_phish-lab.html
  25_Slides/html/g68-L04_footprint-permissions.html
  25_Slides/html/g68-L05_chatbots-ai-companions.html
  25_Slides/html/g68-L06_grooming-patterns.html
  25_Slides/html/g68-L07_pressure-online-response-drill-stop-save-tell-re.html
  25_Slides/html/g68-L08_fakes-that-hurt.html
  25_Slides/html/g68-L09_group-chat-dynamics.html
  25_Slides/html/g68-L10_built-to-keep-you-scrolling.html
  25_Slides/html/g68-P1_work-pressure-and-promises-online-recognising-tr.html
  25_Slides/html/g68-P2_scroll-science-how-feeds-and-notifications-pull-.html
  25_Slides/html/g68-P3_fact-fiction-or-fake-check-before-you-share.html
  25_Slides/html/g912-L01_threat-model-yourself.html
  25_Slides/html/g912-L02_credentials-and-passkeys.html
  25_Slides/html/g912-L03_social-engineering-case-lab.html
  25_Slides/html/g912-L04_data-brokers-and-location.html
  25_Slides/html/g912-L05_sextortion-and-image-abuse.html
  25_Slides/html/g912-L06_synthetic-media-and-truth.html
  25_Slides/html/g912-L07_coercion-in-relationships-online.html
  25_Slides/html/g912-L08_be-the-helper.html
  25_Slides/html/g912-L09_ethics-and-careers-in-security.html
  25_Slides/html/g912-L10_capstone-my-defense-plan.html
  25_Slides/html/g912-P1_recruitment-online-spot-it-say-it-report-it.html
  25_Slides/html/g912-P2_mind-mood-and-the-scroll.html
  25_Slides/html/g912-P3_whose-goal-is-it.html
  25_Slides/html/g912-P4_from-mean-to-harmful-recognize-respond-report.html
  25_Slides/html/index.html
  25_Slides/html/k2-L01_my-tell-someone-team.html
  25_Slides/html/k2-L02_secret-passwords.html
  25_Slides/html/k2-L03_pause-and-ask.html
  25_Slides/html/k2-L04_the-oops-button.html
  25_Slides/html/k2-L05_private-vs-public.html
  25_Slides/html/k2-L06_online-friends-vs-real-friends.html
  25_Slides/html/k2-L07_kind-clicks.html
  25_Slides/html/k2-L08_real-or-pretend.html
  25_Slides/html/k2-L09_my-body-is-mine.html
  25_Slides/html/k2-L10_screen-balance.html
  25_Slides/pptx/g35-L01_the-help-ladder.pptx
  25_Slides/pptx/g35-L02_passphrase-lab.pptx
  25_Slides/pptx/g35-L03_scam-spotters.pptx
  25_Slides/pptx/g35-L04_secret-code-lab.pptx
  25_Slides/pptx/g35-L05_data-detective.pptx
  25_Slides/pptx/g35-L06_game-chat-red-flags.pptx
  25_Slides/pptx/g35-L07_upstander-moves.pptx
  25_Slides/pptx/g35-L08_real-or-fake.pptx
  25_Slides/pptx/g35-L09_family-code-word.pptx
  25_Slides/pptx/g35-L10_oops-recovery.pptx
  25_Slides/pptx/g68-L01_help-ladder-real-practice.pptx
  25_Slides/pptx/g68-L02_account-defense.pptx
  25_Slides/pptx/g68-L03_phish-lab.pptx
  25_Slides/pptx/g68-L04_footprint-permissions.pptx
  25_Slides/pptx/g68-L05_chatbots-ai-companions.pptx
  25_Slides/pptx/g68-L06_grooming-patterns.pptx
  25_Slides/pptx/g68-L07_pressure-online-response-drill-stop-save-tell-re.pptx
  25_Slides/pptx/g68-L08_fakes-that-hurt.pptx
  25_Slides/pptx/g68-L09_group-chat-dynamics.pptx
  25_Slides/pptx/g68-L10_built-to-keep-you-scrolling.pptx
  25_Slides/pptx/g68-P1_work-pressure-and-promises-online-recognising-tr.pptx
  25_Slides/pptx/g68-P2_scroll-science-how-feeds-and-notifications-pull-.pptx
  25_Slides/pptx/g68-P3_fact-fiction-or-fake-check-before-you-share.pptx
  25_Slides/pptx/g912-L01_threat-model-yourself.pptx
  25_Slides/pptx/g912-L02_credentials-and-passkeys.pptx
  25_Slides/pptx/g912-L03_social-engineering-case-lab.pptx
  25_Slides/pptx/g912-L04_data-brokers-and-location.pptx
  25_Slides/pptx/g912-L05_sextortion-and-image-abuse.pptx
  25_Slides/pptx/g912-L06_synthetic-media-and-truth.pptx
  25_Slides/pptx/g912-L07_coercion-in-relationships-online.pptx
  25_Slides/pptx/g912-L08_be-the-helper.pptx
  25_Slides/pptx/g912-L09_ethics-and-careers-in-security.pptx
  25_Slides/pptx/g912-L10_capstone-my-defense-plan.pptx
  25_Slides/pptx/g912-P1_recruitment-online-spot-it-say-it-report-it.pptx
  25_Slides/pptx/g912-P2_mind-mood-and-the-scroll.pptx
  25_Slides/pptx/g912-P3_whose-goal-is-it.pptx
  25_Slides/pptx/g912-P4_from-mean-to-harmful-recognize-respond-report.pptx
  25_Slides/pptx/k2-L01_my-tell-someone-team.pptx
  25_Slides/pptx/k2-L02_secret-passwords.pptx
  25_Slides/pptx/k2-L03_pause-and-ask.pptx
  25_Slides/pptx/k2-L04_the-oops-button.pptx
  25_Slides/pptx/k2-L05_private-vs-public.pptx
  25_Slides/pptx/k2-L06_online-friends-vs-real-friends.pptx
  25_Slides/pptx/k2-L07_kind-clicks.pptx
  25_Slides/pptx/k2-L08_real-or-pretend.pptx
  25_Slides/pptx/k2-L09_my-body-is-mine.pptx
  25_Slides/pptx/k2-L10_screen-balance.pptx

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
