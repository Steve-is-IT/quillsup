Hackles Club (out-of-school)
============================

Hackles: a free kit. The whole kit is at quillsup.org

WHAT IS INSIDE
--------------
Leader guides, three age tracks, family night, library toolkit and volunteer training for clubs and libraries.

  30_Clubs/00_Start_Here_Club_Leaders.docx
  30_Clubs/00_Start_Here_Club_Leaders.pdf
  30_Clubs/01_Club_Card_Sets.docx
  30_Clubs/01_Club_Card_Sets.pdf
  30_Clubs/02_Track_A_Ages_5-7_Little_Hackles.docx
  30_Clubs/02_Track_A_Ages_5-7_Little_Hackles.pdf
  30_Clubs/03_Track_B_Ages_8-11_Hands-On_Hackers.docx
  30_Clubs/03_Track_B_Ages_8-11_Hands-On_Hackers.pdf
  30_Clubs/04_Track_C_Ages_12-15_Case_Files.docx
  30_Clubs/04_Track_C_Ages_12-15_Case_Files.pdf
  30_Clubs/05_Family_Night_Kit.docx
  30_Clubs/05_Family_Night_Kit.pdf
  30_Clubs/06_Hackles_Patch_Skills_Checklist.docx
  30_Clubs/06_Hackles_Patch_Skills_Checklist.pdf
  30_Clubs/07_Homeschool_Co-op_12_Week_Plan.docx
  30_Clubs/07_Homeschool_Co-op_12_Week_Plan.pdf
  30_Clubs/08_Leader_Orientation_90_Minutes.docx
  30_Clubs/08_Leader_Orientation_90_Minutes.pdf
  30_Clubs/09_Registration_Form_Template.docx
  30_Clubs/09_Registration_Form_Template.pdf
  30_Clubs/10_Parent_Letter_and_Permission_Slip.docx
  30_Clubs/10_Parent_Letter_and_Permission_Slip.pdf
  30_Clubs/11_Schedule_Planner.docx
  30_Clubs/11_Schedule_Planner.pdf
  30_Clubs/12_Adult_Sign_In_and_Impact_Tally.docx
  30_Clubs/12_Adult_Sign_In_and_Impact_Tally.pdf
  30_Clubs/13_Certificate_and_Badge_Design_Brief.docx
  30_Clubs/13_Certificate_and_Badge_Design_Brief.pdf
  30_Clubs/14_Library_Toolkit.docx
  30_Clubs/14_Library_Toolkit.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles (quillsup.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
