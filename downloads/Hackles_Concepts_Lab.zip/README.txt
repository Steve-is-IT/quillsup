Concepts Lab
============

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
14 unplugged demos behind the ideas of security (defense only), with an index.

  Concepts_Lab_Index.docx
  Concepts_Lab_Index.pdf
  Demo_01_Long_Passphrases.docx
  Demo_01_Long_Passphrases.pdf
  Demo_02_Mystery_Fingerprints_Hashing.docx
  Demo_02_Mystery_Fingerprints_Hashing.pdf
  Demo_03_Anatomy_of_a_Phish.docx
  Demo_03_Anatomy_of_a_Phish.pdf
  Demo_04_Secret_Codes_to_Real_Encryption.docx
  Demo_04_Secret_Codes_to_Real_Encryption.pdf
  Demo_05_Internet_as_Postal_System.docx
  Demo_05_Internet_as_Postal_System.pdf
  Demo_06_Two_Locks_Better_Than_One.docx
  Demo_06_Two_Locks_Better_Than_One.pdf
  Demo_07_Updates_Patch_the_Hole.docx
  Demo_07_Updates_Patch_the_Hole.pdf
  Demo_08_Social_Engineering_Defense.docx
  Demo_08_Social_Engineering_Defense.pdf
  Demo_09_Data_Footprints_and_Data_Brokers.docx
  Demo_09_Data_Footprints_and_Data_Brokers.pdf
  Demo_10_Backups_and_Ransomware_Recovery.docx
  Demo_10_Backups_and_Ransomware_Recovery.pdf
  Demo_11_Malware_Metaphors_Trojan_Horse_Sort.docx
  Demo_11_Malware_Metaphors_Trojan_Horse_Sort.pdf
  Demo_12_Spot_the_Fake.docx
  Demo_12_Spot_the_Fake.pdf
  Demo_13_Incident_Response_Drill_Hotwash.docx
  Demo_13_Incident_Response_Drill_Hotwash.pdf
  Demo_14_Ethics_Law_and_Careers.docx
  Demo_14_Ethics_Law_and_Careers.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
