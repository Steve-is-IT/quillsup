Games and Fun
=============

Hackles: a free kit by Competence Collective, competencecollective.org. Get the whole kit at quillsup.org

WHAT IS INSIDE
--------------
Games, read-alouds, songs, puppets, bingo, jokes, and the Hackles Day event plan and kit.

  00_Games_and_Fun_Pack_Start_Here.docx
  00_Games_and_Fun_Pack_Start_Here.pdf
  01_Spot_the_Fishy_Card_Game.docx
  01_Spot_the_Fishy_Card_Game.pdf
  02_The_Hackles_Trail_Board_Game.docx
  02_The_Hackles_Trail_Board_Game.pdf
  03_Mission_Quiet_Door_Escape_Missions.docx
  03_Mission_Quiet_Door_Escape_Missions.pdf
  04_Read_Alouds_and_Graphic_Stories.docx
  04_Read_Alouds_and_Graphic_Stories.pdf
  05_Songs_Chants_and_Movement_Breaks.docx
  05_Songs_Chants_and_Movement_Breaks.pdf
  06_Puppet_Show_and_Role_Play_Library.docx
  06_Puppet_Show_and_Role_Play_Library.pdf
  07_Bingo_Passport_Badges_and_Awards.docx
  07_Bingo_Passport_Badges_and_Awards.pdf
  08_Jokes_Riddles_and_Brain_Teasers.docx
  08_Jokes_Riddles_and_Brain_Teasers.pdf
  09_Hackles_Day_Event_Plan.docx
  09_Hackles_Day_Event_Plan.pdf
  Hackles_Day_Kit.docx
  Hackles_Day_Kit.pdf

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles by Competence Collective (competencecollective.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
