Coloring and Activity Books
===========================

Hackles: a free kit. The whole kit is at quillsup.org

WHAT IS INSIDE
--------------
Print-ready PDFs: 40-page coloring book and 24 activity pages, plus line art.

  Hackles_Activity_Book.pdf
  Hackles_Activity_Book_contact_sheet.png
  Hackles_Coloring_Book.pdf
  activities/README.docx
  activities/README.pdf
  activities/page00_cover.svg
  activities/page01_my_trusted_grown_ups_team.svg
  activities/page02_draw_what_hackle_sees.svg
  activities/page03_passphrase_monster.svg
  activities/page04_safe_and_kind_comment.svg
  activities/page05_my_help_ladder.svg
  activities/page06_family_code_symbol.svg
  activities/page07_hackles_champ_self_portrait.svg
  activities/page08_how_to_draw_hackle.svg
  activities/page09_how_to_draw_latch.svg
  activities/page10_complete_the_picture.svg
  activities/page11_maze_find_buddy.svg
  activities/page12_maze_password_vault.svg
  activities/page13_maze_tell_someone_path.png
  activities/page13_maze_tell_someone_path.svg
  activities/page14_wordsearch_safety_words.svg
  activities/page15_wordsearch_super_secret.svg
  activities/page16_dot_to_dot_hackles_up.svg
  activities/page17_dot_to_dot_latch.svg
  activities/page18_match_friend_to_job.svg
  activities/page19_match_scam_to_pause.svg
  activities/page20_spot_difference_desk.svg
  activities/page21_spot_difference_chat.svg
  activities/page22_real_or_pretend.svg
  activities/page23_crossword.svg
  activities/page24_secret_code.svg
  activities/page25_finger_puppets.svg
  activities/page26_paper_bag_puppet.svg
  activities/page27_hackles_up_down_paddle.svg
  activities/page28_popup_tuft_card.svg
  activities/page29_champ_headband.svg
  activities/page30_helper_hand_card.svg
  activities/page31_door_hanger.svg
  activities/page32_desk_tent.svg
  activities/page33_certificates_champ_helper.svg
  activities/page34_certificates_teacher_family.svg
  activities/page35_sticker_sheet.svg
  activities/page36_bookmarks.svg
  activities/page37_hackles_passport_bonus.svg
  activities/page38_key_wordsearch_1.svg
  activities/page39_key_wordsearch_2.svg
  activities/page40_key_mazes.svg
  activities/page41_key_crossword_and_code.svg
  activities/page42_key_matching.svg
  activities/page43_key_spot_and_real.svg
  coloring/Contact_Sheet.png
  coloring/README.docx
  coloring/README.pdf
  coloring/cover.svg
  coloring/index.svg
  coloring/page01.svg
  coloring/page02.svg
  coloring/page03.svg
  coloring/page04.svg
  coloring/page05.svg
  coloring/page06.svg
  coloring/page07.svg
  coloring/page08.svg
  coloring/page09.svg
  coloring/page10.svg
  coloring/page11.svg
  coloring/page12.svg
  coloring/page13.svg
  coloring/page14.svg
  coloring/page15.svg
  coloring/page16.svg
  coloring/page17.svg
  coloring/page18.svg
  coloring/page19.svg
  coloring/page20.svg
  coloring/page21.svg
  coloring/page22.svg
  coloring/page23.svg
  coloring/page24.svg
  coloring/page25.svg
  coloring/page26.svg
  coloring/page27.svg
  coloring/page28.svg
  coloring/page29.svg
  coloring/page30.svg
  coloring/page31.svg
  coloring/page32.svg
  coloring/page33.svg
  coloring/page34.svg
  coloring/page35.svg
  coloring/page36.svg
  coloring/page37.svg
  coloring/page38.svg
  coloring/page39.svg
  coloring/page40.svg
  coloring/page41.svg
  coloring/page42.svg
  coloring/page43.svg
  coloring/page44.svg
  coloring/page45.svg
  coloring/page46.svg
  coloring/page47.svg
  coloring/page48.svg
  coloring/page49.svg
  coloring/page50.svg

FILE TYPES
Word (.docx) is the editable master. PDF copies are included where they exist.
Folders named TEACHERS_ONLY hold answer keys: keep them away from students.

STATUS
------
PILOT DRAFT: reviewed by AI only. A counselor and attorney review is pending. Do not rely on state-law statements. Verify hotline numbers before use. Not evaluated in a controlled study. Not a substitute for your school's safeguarding procedures, counseling, or professional advice.

LICENSE
-------
© 2026 Competence Collective. Lesson text and teaching materials: CC BY-NC 4.0 (free to print, share and adapt for non-commercial use with credit). The Hackles name, logos, characters and artwork are not covered by that license: print and share them unaltered for classroom and family use; any other use needs written permission. [VERIFY with counsel] Credit line: "Hackles (quillsup.org)".

Feedback and corrections: [CONTACT: to be added]. Never send a child's name, photo or details.
No accounts. No tracking. No student data.
